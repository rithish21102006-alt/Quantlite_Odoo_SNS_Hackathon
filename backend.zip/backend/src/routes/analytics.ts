import express from 'express';
import pool from '../db';
import { authenticateToken } from '../middleware/auth';

const router = express.Router();

// Admin Analytics (Read-only)
router.get('/', authenticateToken, async (req, res) => {
    try {
        const [stats]: any = await pool.execute('SELECT * FROM admin_analytics ORDER BY recorded_at DESC LIMIT 10');

        // Aggregate some stats on the fly if needed
        const [counts]: any = await pool.execute(`
      SELECT 
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM trips) as total_trips,
        (SELECT COUNT(*) FROM shared_trips) as total_shares
    `);

        res.json({
            history: stats,
            current: counts[0]
        });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
