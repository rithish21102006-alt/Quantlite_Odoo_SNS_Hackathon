import express from 'express';
import crypto from 'crypto';
import pool from '../db';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Generate share link
router.post('/share/:tripId', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { tripId } = req.params;
        const share_token = crypto.randomBytes(16).toString('hex');
        const expires_at = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

        await pool.execute(
            'INSERT INTO shared_trips (trip_id, share_token, expires_at) VALUES (?, ?, ?)',
            [tripId, share_token, expires_at]
        );

        res.json({ share_token, url: `/api/sharing/view/${share_token}` });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// View shared trip (Public)
router.get('/view/:token', async (req, res) => {
    try {
        const { token } = req.params;
        const [shares]: any = await pool.execute(
            'SELECT trip_id FROM shared_trips WHERE share_token = ? AND (expires_at > NOW() OR expires_at IS NULL)',
            [token]
        );

        if (shares.length === 0) return res.status(404).json({ error: 'Share link invalid or expired' });

        const tripId = shares[0].trip_id;
        // Reuse logic or call internal logic to get trip details
        const [trips]: any = await pool.execute('SELECT * FROM trips WHERE id = ?', [tripId]);
        const trip = trips[0];

        const [stops]: any = await pool.execute('SELECT * FROM trip_stops WHERE trip_id = ? ORDER BY order_index', [tripId]);
        const [budgets]: any = await pool.execute('SELECT * FROM budgets WHERE trip_id = ?', [tripId]);

        res.json({ ...trip, stops, cost_breakdown: budgets[0] || null });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
