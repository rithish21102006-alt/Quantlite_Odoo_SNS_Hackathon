import express from 'express';
import pool from '../db';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Add city to trip
router.post('/stops', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { trip_id, city_id, city_name, country, start_date, end_date, order_index } = req.body;

        // Verify ownership
        const [trips]: any = await pool.execute('SELECT id FROM trips WHERE id = ? AND user_id = ?', [trip_id, req.user!.id]);
        if (trips.length === 0) return res.status(403).json({ error: 'Permission denied' });

        const [result]: any = await pool.execute(
            'INSERT INTO trip_stops (trip_id, city_id, city_name, country, start_date, end_date, order_index) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [trip_id, city_id || null, city_name, country || null, start_date, end_date, order_index || 0]
        );
        res.status(201).json({
            id: result.insertId,
            trip_id,
            city_id: city_id || null,
            city_name,
            country: country || null,
            start_date,
            end_date,
            order_index: order_index || 0,
            estimated_cost: 0
        });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Update stop
router.put('/stops/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { city_name, country, start_date, end_date, order_index, notes } = req.body;
        await pool.execute(
            'UPDATE trip_stops SET city_name = ?, country = ?, start_date = ?, end_date = ?, order_index = ?, notes = ? WHERE id = ?',
            [city_name, country || null, start_date, end_date, order_index || 0, notes || null, req.params.id]
        );
        res.json({ message: 'Stop updated' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Delete stop
router.delete('/stops/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        await pool.execute('DELETE FROM trip_stops WHERE id = ?', [req.params.id]);
        res.json({ message: 'Stop deleted' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Add activity to stop
router.post('/activities', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { trip_stop_id, activity_id, custom_activity_name, estimated_cost, notes, scheduled_time } = req.body;

        const [result]: any = await pool.execute(
            'INSERT INTO stop_activities (trip_stop_id, activity_id, custom_activity_name, estimated_cost, notes, scheduled_time) VALUES (?, ?, ?, ?, ?, ?)',
            [trip_stop_id, activity_id || null, custom_activity_name || null, estimated_cost || 0, notes || null, scheduled_time || null]
        );

        res.status(201).json({
            id: result.insertId,
            trip_stop_id,
            activity_id: activity_id || null,
            custom_activity_name: custom_activity_name || null,
            estimated_cost: parseFloat(estimated_cost || 0),
            notes: notes || null,
            scheduled_time: scheduled_time || null
        });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Update activity
router.put('/activities/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { activity_id, custom_activity_name, estimated_cost, notes, scheduled_time } = req.body;
        await pool.execute(
            'UPDATE stop_activities SET activity_id = ?, custom_activity_name = ?, estimated_cost = ?, notes = ?, scheduled_time = ? WHERE id = ?',
            [activity_id || null, custom_activity_name || null, estimated_cost || 0, notes || null, scheduled_time || null, req.params.id]
        );
        res.json({ message: 'Activity updated' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Delete activity
router.delete('/activities/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        await pool.execute('DELETE FROM stop_activities WHERE id = ?', [req.params.id]);
        res.json({ message: 'Activity deleted' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Update/Calculate Budget
router.post('/budget/:tripId', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { tripId } = req.params;

        // 1. Get all stops for this trip
        const [stops]: any = await pool.execute('SELECT * FROM trip_stops WHERE trip_id = ?', [tripId]);

        // 2. Initialize totals
        let totalAccommodation = 0;
        let totalFood = 0;
        let totalTransport = 0;
        let totalActivities = 0;
        let totalDays = 0;

        // 3. Process each stop
        for (const stop of stops) {
            // Calculate days: DATEDIFF + 1
            const start = new Date(stop.start_date);
            const end = new Date(stop.end_date);
            const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1);
            totalDays += days;

            // Get city cost index
            const [cityCosts]: any = await pool.execute(
                'SELECT * FROM city_cost_index WHERE city_name = ?',
                [stop.city_name]
            );

            let stopBaseCost = 0;
            if (cityCosts.length > 0) {
                const cost = cityCosts[0];
                const index = parseFloat(cost.cost_index || '1');

                const stopAcc = parseFloat(cost.accommodation_per_day_usd) * days * index;
                const stopFood = parseFloat(cost.food_per_day_usd) * days * index;
                const stopTrans = parseFloat(cost.transport_per_day_usd) * days * index;

                totalAccommodation += stopAcc;
                totalFood += stopFood;
                totalTransport += stopTrans;
                stopBaseCost = stopAcc + stopFood + stopTrans;
            }

            // Get activities for this stop
            const [activities]: any = await pool.execute(
                'SELECT SUM(estimated_cost) as total FROM stop_activities WHERE trip_stop_id = ?',
                [stop.id]
            );
            const stopActivityCost = parseFloat(activities[0].total || '0');
            totalActivities += stopActivityCost;

            // Update stop's total estimated cost
            const stopTotal = stopBaseCost + stopActivityCost;
            await pool.execute('UPDATE trip_stops SET estimated_cost = ? WHERE id = ?', [stopTotal, stop.id]);
        }

        const totalEstimated = totalAccommodation + totalFood + totalTransport + totalActivities;
        const perDayAverage = totalDays > 0 ? totalEstimated / totalDays : 0;

        // 4. Upsert budget
        await pool.execute(
            `INSERT INTO budgets (
                trip_id, 
                total_accommodation, 
                total_food, 
                total_transport, 
                total_activities, 
                total_estimated_cost, 
                per_day_average, 
                calculated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW()) 
            ON DUPLICATE KEY UPDATE 
                total_accommodation = VALUES(total_accommodation),
                total_food = VALUES(total_food),
                total_transport = VALUES(total_transport),
                total_activities = VALUES(total_activities),
                total_estimated_cost = VALUES(total_estimated_cost),
                per_day_average = VALUES(per_day_average),
                calculated_at = NOW()`,
            [tripId, totalAccommodation, totalFood, totalTransport, totalActivities, totalEstimated, perDayAverage]
        );

        res.json({
            total_accommodation: totalAccommodation,
            total_food: totalFood,
            total_transport: totalTransport,
            total_activities: totalActivities,
            total_estimated_cost: totalEstimated,
            per_day_average: perDayAverage
        });
    } catch (error: any) {
        console.error('Budget calculation error:', error);
        res.status(500).json({ error: error.message });
    }
});

// Reorder stops
router.post('/reorder/:tripId', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { stopIds } = req.body;
        for (let i = 0; i < stopIds.length; i++) {
            await pool.execute('UPDATE trip_stops SET order_index = ? WHERE id = ?', [i, stopIds[i]]);
        }
        res.json({ message: 'Stops reordered' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
