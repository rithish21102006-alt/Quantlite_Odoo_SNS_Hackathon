import express from 'express';
import pool from '../db';
import { authenticateToken } from '../middleware/auth';

const router = express.Router();

// Get all activities from catalog
router.get('/', authenticateToken, async (req, res) => {
    try {
        const { type } = req.query;
        let sql = 'SELECT * FROM activities';
        const params = [];

        if (type) {
            sql += ' WHERE type = ?';
            params.push(type);
        }

        sql += ' ORDER BY name ASC';

        const [rows] = await pool.execute(sql, params);
        res.json(rows);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Search activities
router.get('/search', authenticateToken, async (req, res) => {
    try {
        const { q } = req.query;
        if (!q) return res.json([]);

        const [rows] = await pool.execute(
            'SELECT * FROM activities WHERE name LIKE ? OR description LIKE ? ORDER BY name ASC LIMIT 20',
            [`%${q}%`, `%${q}%`]
        );
        res.json(rows);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
