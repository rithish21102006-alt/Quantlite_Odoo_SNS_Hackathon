import express from 'express';
import pool from '../db';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get all trips for user
router.get('/', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT * FROM trips WHERE user_id = ? ORDER BY created_at DESC',
            [req.user!.id]
        );
        res.json(rows);
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Create trip
router.post('/', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { name, description, start_date, end_date, cover_image_url } = req.body;
        const [result]: any = await pool.execute(
            'INSERT INTO trips (user_id, name, description, start_date, end_date, cover_image_url) VALUES (?, ?, ?, ?, ?, ?)',
            [req.user!.id, name, description || null, start_date, end_date, cover_image_url || null]
        );
        res.status(201).json({ id: result.insertId, name, description });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Get single trip with stops and activities
router.get('/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const tripId = req.params.id;
        const [trips]: any = await pool.execute('SELECT * FROM trips WHERE id = ? AND user_id = ?', [tripId, req.user!.id]);

        if (trips.length === 0) return res.status(404).json({ error: 'Trip not found' });
        const trip = trips[0];

        // Get stops
        const [stops]: any = await pool.execute('SELECT * FROM trip_stops WHERE trip_id = ? ORDER BY order_index', [tripId]);

        // Get activities for each stop
        const stopsWithActivities = await Promise.all(stops.map(async (stop: any) => {
            const [rows]: any = await pool.execute(
                `SELECT sa.*, a.name as cat_name, a.type as cat_type, a.description as cat_desc 
         FROM stop_activities sa 
         LEFT JOIN activities a ON sa.activity_id = a.id 
         WHERE sa.trip_stop_id = ?`,
                [stop.id]
            );

            const activities = rows.map((row: any) => {
                const { cat_name, cat_type, cat_desc, ...sa } = row;
                return {
                    ...sa,
                    estimated_cost: parseFloat(sa.estimated_cost),
                    activity: cat_name ? { name: cat_name, type: cat_type, description: cat_desc } : null
                };
            });

            return {
                ...stop,
                estimated_cost: parseFloat(stop.estimated_cost),
                activities
            };
        }));

        // Get budget
        const [budgets]: any = await pool.execute('SELECT * FROM budgets WHERE trip_id = ?', [tripId]);

        let budget = null;
        if (budgets.length > 0) {
            const b = budgets[0];
            budget = {
                ...b,
                total_accommodation: parseFloat(b.total_accommodation),
                total_food: parseFloat(b.total_food),
                total_transport: parseFloat(b.total_transport),
                total_activities: parseFloat(b.total_activities),
                total_estimated_cost: parseFloat(b.total_estimated_cost),
                per_day_average: parseFloat(b.per_day_average)
            };
        }

        res.json({ ...trip, stops: stopsWithActivities, cost_breakdown: budget });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Update trip
router.put('/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        const { name, description, start_date, end_date, is_public } = req.body;
        await pool.execute(
            'UPDATE trips SET name = ?, description = ?, start_date = ?, end_date = ?, is_public = ? WHERE id = ? AND user_id = ?',
            [name, description || null, start_date, end_date, is_public ?? 0, req.params.id, req.user!.id]
        );
        res.json({ message: 'Trip updated successfully' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

// Delete trip
router.delete('/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
        await pool.execute('DELETE FROM trips WHERE id = ? AND user_id = ?', [req.params.id, req.user!.id]);
        res.json({ message: 'Trip deleted' });
    } catch (error: any) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
