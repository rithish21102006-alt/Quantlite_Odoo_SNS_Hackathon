import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import authRoutes from './routes/auth';
import tripRoutes from './routes/trips';
import cityRoutes from './routes/cities';
import sharingRoutes from './routes/sharing';
import analyticsRoutes from './routes/analytics';
import catalogRoutes from './routes/catalog';

dotenv.config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/trips', tripRoutes);
app.use('/api/cities', cityRoutes);
app.use('/api/sharing', sharingRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/catalog', catalogRoutes);

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date() });
});

// Serve static assets in production
const distPath = path.join(__dirname, '../../dist');
app.use(express.static(distPath));

// Catch-all route for SPA (Redirect all remaining GET requests to index.html)
// Using app.use with a path check to avoid Express 5 wildcard parsing errors
app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api') && !req.path.includes('.')) {
        return res.sendFile(path.join(distPath, 'index.html'));
    }
    next();
});

// Global error handler
app.use((err: any, req: any, res: any, next: any) => {
    console.error('Unhandled Error:', err);
    res.status(500).json({ error: err.message || 'Internal Server Error' });
});

app.listen(port, () => {
    console.log(`🚀 GlobeTrotter Backend listening at http://localhost:${port}`);
});
